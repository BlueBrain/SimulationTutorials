nrnivmodl ./mechanisms
nrngui mosinit.hoc
